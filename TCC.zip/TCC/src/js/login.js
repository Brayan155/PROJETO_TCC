document.querySelector('.bookmark').addEventListener("mouseover", function () {
    document.querySelector('.Discipulus').style.opacity = '1'
})

document.querySelector('.bookmark').addEventListener("mouseout", function () {
    document.querySelector('.Discipulus').style.opacity = '0'
})