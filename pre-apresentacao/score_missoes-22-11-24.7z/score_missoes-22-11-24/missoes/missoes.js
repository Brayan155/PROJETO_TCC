document.querySelectorAll('.toggle-objective').forEach((button, index) => {
    button.addEventListener('click', () => {
        const objective = document.querySelectorAll('.mission-objective')[index];
        objective.style.display = objective.style.display === 'block' ? 'none' : 'block';
    });
});
   
document.addEventListener("DOMContentLoaded", () => {
    // Seleciona todos os botões de "Feito"
    const doneButtons = document.querySelectorAll(".mark-done")
    const progressBars = document.querySelectorAll('.progress-bar-container')

    doneButtons.forEach((button, index) => {
        button.addEventListener("click", () => {
            // Pega os pontos atuais do localStorage, ou inicia em 0
            let currentPoints = parseInt(localStorage.getItem('pontos')) || 0

            // Incrementa 10 pontos
            currentPoints += 10

            // Atualiza o localStorage com os novos pontos
            localStorage.setItem('pontos', currentPoints)

            // Desativa o botão para evitar novos cliques
            button.disabled = true
            button.innerText = "Concluído!" // Mensagem de feedback no botão

            // Feedback visual para o progresso
            if (progressBars[index]) {
                const bar = progressBars[index]

                // Reseta o estilo da barra antes da animação
                bar.style.background = 'lightgray'
                bar.style.width = '0%'
                bar.style.transition = 'width 2s ease-in-out' // Transição para a animação de carregamento

                // Inicia a animação de preenchimento
                setTimeout(() => {
                    bar.style.width = '100%'
                    bar.style.background = '#13678A'
                }, 30);

                // Aguarda a animação terminar antes de fazer a barra desaparecer
                setTimeout(() => {
                    bar.style.transition = 'opacity 1s ease' // Transição para a opacidade
                    bar.style.opacity = '0' // Faz a barra desaparecer
                    setTimeout(() => {
                        bar.style.display = 'none' // Remove a barra visualmente
                    }, 1000) // Aguarda o término da transição
                }, 1000) // Aguarda 2 segundos para começar a desaparecer
            }

            // Feedback ao usuário
            alert('Você ganhou 10 pontos!')
        });
    });
});

