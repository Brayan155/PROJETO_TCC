document.addEventListener("DOMContentLoaded", () => {
    // Pega os pontos do localStorage
    let pontos = localStorage.getItem('pontos') || 0;

    // Atualiza o elemento com id 'pontos'
    document.getElementById('pontos').textContent = pontos;
});



