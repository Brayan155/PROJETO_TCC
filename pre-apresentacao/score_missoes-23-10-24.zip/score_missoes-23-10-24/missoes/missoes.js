document.querySelectorAll('.toggle-objective').forEach((button, index) => {
    button.addEventListener('click', () => {
        const objective = document.querySelectorAll('.mission-objective')[index];
        objective.style.display = objective.style.display === 'block' ? 'none' : 'block';
    });
});
   
document.addEventListener("DOMContentLoaded", () => {
    // Seleciona todos os botões de "Feito"
    const doneButtons = document.querySelectorAll(".mark-done");

    doneButtons.forEach(button => {
        button.addEventListener("click", () => {
            // Pega os pontos atuais do localStorage, ou inicia em 0
            let currentPoints = parseInt(localStorage.getItem('pontos')) || 0;

            // Incrementa 10 pontos
            currentPoints += 10;

            // Atualiza o localStorage com os novos pontos
            localStorage.setItem('pontos', currentPoints);

            // Você pode adicionar uma mensagem de feedback se quiser
            alert('Você ganhou 10 pontos!');
        });
    });
});
