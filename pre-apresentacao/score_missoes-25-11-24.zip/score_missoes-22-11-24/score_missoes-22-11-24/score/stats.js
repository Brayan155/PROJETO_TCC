document.addEventListener("DOMContentLoaded", () => {
    // Pega os pontos do localStorage
    let pontos = localStorage.getItem('pontos') || 0

    // Atualiza o elemento com id 'pontos'
    document.getElementById('pontos').textContent = pontos
})


// FUNÇÃO RECEBER MEDALHA

function remedalha() {
    const medalhasDiv = document.querySelector('#medalhas') // Seleciona a div 'medalhas'
    const pontosDisplay = document.getElementById('pontos') // Elemento para exibir os pontos
    let pontos = parseInt(localStorage.getItem('pontos')) || 0 // Pega os pontos do localStorage ou define como 0

    // Define as condições específicas para cada botão no JS
    const conditions = {
        bronzebtn: { required: 1000, name: "Bronze" },
        silverbtn: { required: 2000, name: "Prata" },
        goldbtn: { required: 5000, name: "Ouro" }
    };

    // Seleciona todos os botões dentro da div 'medalhas'
    const medalhasBTN = medalhasDiv.querySelectorAll('button')

    medalhasBTN.forEach((button) => {
        button.addEventListener('click', () => {
            const className = button.classList[0] // Obtém a classe do botão (ex: 'bronzebtn')
            const condition = conditions[className] // Busca o requisito baseado na classe

            if (!condition) {
                alert("Condição não encontrada para este botão.")
                return
            }

            // Verifica se o botão já foi clicado
            if (button.disabled) {
                alert('Você já resgatou essa medalha!')
                return
            }

            // Verifica se há pontos suficientes
            if (pontos >= condition.required) {
                pontos -= condition.required // Deduz os pontos com base na condição
                localStorage.setItem('pontos', pontos) // Atualiza o localStorage
                pontosDisplay.textContent = pontos // Atualiza a exibição dos pontos

                alert(`Você resgatou a medalha de ${condition.name}!`) // Mostra o nome da medalha

                button.disabled = true; // Desativa o botão para impedir outro clique
                button.style.opacity = 0.5 // Ajusta o estilo para indicar que está desativado
                button.style.cursor = 'not-allowed' // Muda o cursor para indicar que não pode ser clicado
                
            } else {
                alert('Pontos insuficientes!') // Mensagem de erro
            }
        })
    })
}




