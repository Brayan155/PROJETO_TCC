document.querySelectorAll('.toggle-objective').forEach((button, index) => {
    button.addEventListener('click', () => {
        const objective = document.querySelectorAll('.mission-objective')[index];
        objective.style.display = objective.style.display === 'block' ? 'none' : 'block'
    })
})

document.addEventListener("DOMContentLoaded", () => {
    // Seleciona todas as missões
    const missionCards = document.querySelectorAll(".mission-card")
    const doneButtons = document.querySelectorAll(".mark-done")
    const progressBars = document.querySelectorAll(".progress-bar-container")

    // Define pontuações aleatórias para cada missão
    missionCards.forEach((card) => {
        const randomPoints = Math.floor(Math.random() * 101) + 50 // Gera pontos entre 50 e 150
        card.setAttribute("data-points", randomPoints) // Adiciona ao atributo data-points
    });

    // Adiciona evento de clique aos botões
    doneButtons.forEach((button, index) => {
        button.addEventListener("click", () => {
            // Obtém o elemento da missão correspondente
            const missionCard = button.closest(".mission-card")
            // Pega a pontuação específica da missão
            const missionPoints = parseInt(missionCard.getAttribute("data-points")) || 0

            // Pega os pontos atuais do localStorage, ou inicia em 0
            let currentPoints = parseInt(localStorage.getItem("pontos")) || 0

            // Incrementa os pontos da missão
            currentPoints += missionPoints

            // Atualiza o localStorage com os novos pontos
            localStorage.setItem("pontos", currentPoints)

            // Desativa o botão para evitar novos cliques
            button.disabled = true
            button.innerText = "Concluído!" // Mensagem de feedback no botão

            // Feedback visual para o progresso
            if (progressBars[index]) {
                const bar = progressBars[index]

                // Reseta o estilo da barra antes da animação
                bar.style.background = "lightgray"
                bar.style.width = "0%"
                bar.style.transition = "width 2s ease-in-out" // Transição para a animação de carregamento

                // Inicia a animação de preenchimento
                setTimeout(() => {
                    bar.style.width = "100%"
                    bar.style.background = "#13678A"
                }, 30);

                // Aguarda a animação terminar antes de fazer a barra desaparecer
                setTimeout(() => {
                    bar.style.transition = "opacity 1s ease" // Transição para a opacidade
                    bar.style.opacity = "0" // Faz a barra desaparecer
                    setTimeout(() => {
                        bar.style.display = "none" // Remove a barra visualmente
                    }, 1000) // Aguarda o término da transição
                }, 2000) // Aguarda 2 segundos para começar a desaparecer
            }

            // Feedback ao usuário
            alert(`Você ganhou ${missionPoints} pontos!`)
        })
    })
})

document.addEventListener("DOMContentLoaded", () => {
    const missionContainer = document.querySelector(".row.row-cols-5")
    const missionCards = Array.from(document.querySelectorAll(".mission-card"))

    // Agrupa missões em linhas de 4 e adiciona quebras de linha
    missionContainer.innerHTML = "" // Limpa o conteúdo original
    missionCards.forEach((card, index) => {
        if (index % 4 === 0 && index !== 0) {
            const breakDiv = document.createElement("div")
            breakDiv.className = "break"
            card.style = 'justify-content: center'
            missionContainer.appendChild(breakDiv)
        }
        const colDiv = document.createElement("div")
        colDiv.className = "col"
        colDiv.appendChild(card)
        missionContainer.appendChild(colDiv)
    })
})


